#include <TGUI/TGUI.hpp>
#include <TGUI/Backend/SFML-Graphics.hpp>
#include <filesystem>
#include <thread>
#include <atomic>
#include <vector>
#include <fstream>
#include <stdio.h>
using DWORD = uint32_t;
using LPVOID = void*;
typedef void* HINSTANCE;
typedef wchar_t WCHAR;
typedef const char* LPCSTR;
typedef const WCHAR* LPWCSTR;
typedef unsigned int UINT;
typedef void* HGLOBAL;
typedef void* HRSRC;
typedef void* HMODULE;
extern "C" {
	HRSRC FindResourceA(HMODULE hModule, LPCSTR lpName, LPCSTR lpType);
	HRSRC FindResourceW(HMODULE hModule, LPWCSTR lpName, LPWCSTR lpType);
	HGLOBAL LoadResource(HMODULE hModule, HRSRC hResInfo);
	void* LockResource(HGLOBAL hResData);
	unsigned int SizeofResource(HMODULE hModule, HRSRC hResInfo);
}
bool SaveResourceToFile(const WCHAR* resourceName, const WCHAR* resourceType, const WCHAR* outputFilePath)
{
	// Find a resource
	HRSRC hResource = FindResourceW(NULL, resourceName, resourceType);
	if (hResource == NULL) {
		return false;
	}

	// Load a resource
	HGLOBAL hMemory = LoadResource(NULL, hResource);
	if (hMemory == NULL) {
		return false;
	}

	// Get resource size
	DWORD resourceSize = SizeofResource(NULL, hResource);
	if (resourceSize == 0) {
		return false;
	}

	// Get a pointer to the resource data
	LPVOID resourceData = LockResource(hMemory);
	if (resourceData == NULL) {
		return false;
	}

	// Write data to file
	std::ofstream outputFile(outputFilePath, std::ios::binary);
	if (!outputFile.is_open()) {
		return false;
	}

	outputFile.write(static_cast<const char*>(resourceData), resourceSize);
	outputFile.close();

	return true;
}
tgui::String FormatSize(unsigned int bytes)
{
	constexpr std::string_view suffixes[] = { "B", "KB", "MB", "GB", "TB", "PB" };

	if (bytes == 0)
	{
		return "0 B";
	}

	double size = static_cast<double>(bytes);
	//unsigned int size = bytes;
	int index = 0;

	while (size >= 1024 && index < 5) // 5 � ��������� ������ � suffixes[]
	{
		size /= 1024;
		++index;
	}

	// ����������� � ������ � �����������
	char buffer[32];
	if (size - std::floor(size) < 0.05 || index == 0) // ����� ����� ��� < 1 KB
	{
		snprintf(buffer, sizeof(buffer), "%d %.*s",
			static_cast<int>(std::round(size)),
			static_cast<int>(suffixes[index].length()),
			suffixes[index].data());
	}
	else
	{
		snprintf(buffer, sizeof(buffer), "%.1f %.*s",
			size,
			static_cast<int>(suffixes[index].length()),
			suffixes[index].data());
	}

	return tgui::String(buffer);
}
tgui::String FormatFileTime(const std::filesystem::file_time_type& file_time) {
	// �������� ����� � ���� duration � ������ �����
	auto duration = file_time.time_since_epoch();

	// ������������ � ��������� ����� (time_t)
	auto system_time = std::chrono::system_clock::now() -
		(std::filesystem::file_time_type::clock::now() - file_time);
	std::time_t time = std::chrono::system_clock::to_time_t(system_time);

	// �������� ��������� �����
	std::tm local_time;
#ifdef _WIN32
	localtime_s(&local_time, &time);
#else
	localtime_r(&time, &local_time);
#endif

	// ����������� � ������ (��.��.���� ��:��:��)
	char buf[20];
	std::snprintf(buf, sizeof(buf), "%02d.%02d.%04d %02d:%02d:%02d",
		local_time.tm_mday,
		local_time.tm_mon + 1,
		local_time.tm_year + 1900,
		local_time.tm_hour,
		local_time.tm_min,
		local_time.tm_sec);

	return tgui::String(buf);
}

namespace fs = std::filesystem;
std::atomic<bool> isScanning = false;
std::atomic<bool> updateFiles = false;
std::atomic<bool> folders = true;
std::atomic<unsigned int> fnumb = 0;
std::atomic<unsigned int> dfnumb = 0;
std::atomic<unsigned int> size = 0;
std::atomic<unsigned int> lastSize = 0;
std::atomic<bool> stop = false;
tgui::String path;
std::vector<fs::path> filesVec;

inline unsigned int fsize(fs::path pth) {
	unsigned int sz = 0;
	try {
		if (fs::is_directory(pth)) {
			for (const auto& entry : fs::recursive_directory_iterator(pth)) {
				try {
					if (fs::is_regular_file(entry)) {
						sz += entry.file_size();
					}
				}
				catch (...) {}
			}
		}
	}
	catch (...) {}
	return sz;
}
void sortFiles(std::vector<fs::path>& paths) {
	// ������� ��-�����
	/*for (size_t i = 0; i < paths.size(); ) {
		//if (i < paths.size()) {
			if (!fs::is_regular_file(paths[i])) {
				paths.erase(paths.begin() + i);
			}
		//}
		else {
			++i;
		}
	}*/

	// ���������� ��������� �� �������� �������
	for (size_t i = 0; i < paths.size(); ++i) {
		for (size_t j = 0; j < paths.size() - i - 1; ++j) {
			if (fs::file_size(paths[j]) < fs::file_size(paths[j + 1])) {  // < ������ >
				std::swap(paths[j], paths[j + 1]);
			}
		}
	}
}

void sortFolders(std::vector<fs::path>& paths) {
	/*for (size_t i = 0; i < paths.size(); ) {
		//if (i < paths.size()) {
			if (!fs::is_directory(paths[i])) {

				paths.erase(paths.begin() + i);
			}
		//}
		else {
			++i;
		}
	}*/

	// ���������� ��������� �� �������� �������
	for (size_t i = 0; i < paths.size(); ++i) {
		for (size_t j = 0; j < paths.size() - i - 1; ++j) {
			if (fsize(paths[j]) < fsize(paths[j + 1])) {  // < ������ >
				std::swap(paths[j], paths[j + 1]);
			}
		}
	}
}

void scanFiles(unsigned int fn = fnumb, fs::path p = fs::path(path.toUtf32()), bool first = true) {
	fs::path dir(p);
	if (fs::exists(dir)) {
		if (fs::is_regular_file(dir)) { dir = dir.parent_path(); }
	}
	else {
		dir = L"C:\\";
	}

	isScanning = true;
	try {
		for (const auto& entry : fs::directory_iterator(dir)) {
			try {
				if (!stop) {
					if (fs::is_regular_file(entry)) {
						filesVec.push_back(entry.path());
					}
					if (fs::is_directory(entry) && fn > 0) {
						scanFiles(fn - 1, entry.path(), false);
					}
				}
			}
			catch (...) {}
		}
		size = filesVec.size();
	}
	catch (...) {}

	if (first && !stop) {
		sortFiles(filesVec);
		updateFiles = true;
		isScanning = false;
	}
	return;
}
void scanFolders(unsigned int fn = fnumb, fs::path p = fs::path(path.toUtf32()), bool first = true) {
	fs::path dir(p);
	if (fs::exists(dir)) {
		if (fs::is_regular_file(dir)) { dir = dir.parent_path(); }
	}
	else {
		dir = L"C:\\";
	}

	isScanning = true;
	try {
		for (const auto& entry : fs::directory_iterator(dir)) {
			try {
				if (!stop) {
					if (fs::is_directory(entry) && fn <= 0) {
						filesVec.push_back(entry.path());
					}
					if (fs::is_directory(entry) && fn > 0) {
						scanFolders(fn - 1, entry.path(), false);
					}
				}
			}
			catch (...) {}
		}
		size = filesVec.size();
	}
	catch (...) {}
	if (first && !stop) {
		sortFolders(filesVec);
		updateFiles = true;
		isScanning = false;
	}
	return;
}
void setupWidgets(tgui::Gui& ui) {
	tgui::ChildWindow::Ptr child1 = ui.get<tgui::ChildWindow>("ScanDir");
	child1->setSize("19%", "50%");
	tgui::ChildWindow::Ptr child2 = ui.get<tgui::ChildWindow>("ScanFile");
	child2->setSize("19%", "50%");
	tgui::ListView::Ptr filesl = ui.get<tgui::ListView>("List");
	filesl->addColumn(L"�������");
	filesl->addColumn(L"������");
	filesl->addColumn(L"���� ���������");
	filesl->setColumnExpanded(0, true);
	filesl->setColumnAlignment(1, tgui::HorizontalAlignment::Right);
	filesl->setColumnAutoResize(1, true);
	filesl->setColumnAutoResize(2, true);
	filesl->setResizableColumns(false);
	tgui::Button::Ptr scf = ui.get<tgui::Button>("Scan2");
	scf->onClick([&]() {
		if (isScanning == false) {
			auto finp = ui.get<tgui::EditBox>("FilesInput");
			fnumb = finp->getText().toUInt();
			folders = false;
			filesVec.clear();
			auto files = ui.get<tgui::ListView>("List");
			files->removeAllItems();
			std::vector<tgui::String> col;
			col.push_back(U"���������...");
			col.push_back("");
			col.push_back("");
			files->addItem(col);

			std::thread fthr([] {

				scanFiles();

				});
			fthr.detach();
		}
		});
	tgui::Button::Ptr scfold = ui.get<tgui::Button>("Scan1");
	scfold->onClick([&]() {
		if (isScanning == false) {
			auto finp = ui.get<tgui::EditBox>(L"FoldersInput");
			fnumb = finp->getText().toUInt();
			folders = true;
			filesVec.clear();
			auto files = ui.get<tgui::ListView>("List");
			files->removeAllItems();
			std::vector<tgui::String> col;
			col.push_back(U"���������...");
			col.push_back("");
			col.push_back("");
			files->addItem(col);

			std::thread foldthr([] {

				scanFolders();

				});
			foldthr.detach();
		}
		});
	auto pathinp = ui.get<tgui::EditBox>("PathInput");
	pathinp->setMouseCursor(tgui::Cursor::Type::Text);
	pathinp->onTextChange([&]() {
		auto pathinp2 = ui.get<tgui::EditBox>("PathInput");
		path = pathinp2->getText();
		});
	auto eln = ui.get<tgui::EditBox>("ElementsNumber");
	eln->setMouseCursor(tgui::Cursor::Type::Text);
	eln->onTextChange([&]() {
		auto eln2 = ui.get<tgui::EditBox>("ElementsNumber");
		dfnumb = eln2->getText().toUInt();
		});
}

int WinMain() {
	SaveResourceToFile(L"#101",L"PNG",L"TempFileScannerIcon.png");
	SaveResourceToFile(L"#103",L"TXT",L"TempFileScannerWidgetsList.txt");
	sf::RenderWindow window(sf::VideoMode(sf::Vector2u(800, 600)), "File Scanner", sf::State::Windowed, sf::ContextSettings());
	tgui::Gui gui(window);
	sf::Color color(sf::Color::White);
	window.setIcon(sf::Image(fs::path(L"TempFileScannerIcon.png")));
	gui.loadWidgetsFromFile(L"TempFileScannerWidgetsList.txt");
	remove("TempFileScannerIcon.png");
	remove("TempFileScannerWidgetsList.txt");
	setupWidgets(gui);
	tgui::ListView::Ptr files = gui.get<tgui::ListView>("List");

	while (window.isOpen())
	{
		std::optional<sf::Event> event;
		event = window.pollEvent();
		while (event.has_value())
		{
			gui.handleEvent(event.value());

			if (event.value().is<sf::Event::Closed>()) {
				stop = true;
				std::this_thread::sleep_for(std::chrono::milliseconds(350));
				window.close();
			}
			event = window.pollEvent();
		}
		if (size != lastSize && isScanning) {
			files->removeAllItems();
			std::vector<tgui::String> col;
			col.push_back(U"���������� ���������������� ���������: " + tgui::String(size.load()));
			col.push_back("");
			col.push_back("");
			files->addItem(col);
			lastSize = size.load();
		}
		if (updateFiles == true) {
			updateFiles = false;
			files->removeAllItems();

			for (unsigned int i = 0; i < dfnumb; i++) {
				if (i < filesVec.size()) {
					std::vector<tgui::String> col;
					col.push_back(filesVec[i].generic_u32string());
					if (folders == true) {
						col.push_back(FormatSize(fsize(filesVec[i])));
					}
					else {
						col.push_back(FormatSize(fs::file_size(filesVec[i])));
					}
					auto ftime = fs::last_write_time(filesVec[i]);
					col.push_back(FormatFileTime(ftime));
					files->addItem(col);
				}
			}
		}

		window.clear(color);

		gui.draw();

		window.display();
	}

}
